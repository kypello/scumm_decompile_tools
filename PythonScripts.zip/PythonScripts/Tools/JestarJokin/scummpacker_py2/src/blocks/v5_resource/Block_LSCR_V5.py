from blocks.common import BlockLocalScript
from blocks.v5_base import BlockDefaultV5

class BlockLSCRV5(BlockLocalScript, BlockDefaultV5):
    name = "LSCR"
