from blocks.v5_base import BlockSoundV5, BlockContainerV5

class BlockSOUV5(BlockSoundV5, BlockContainerV5):
    name = "SOU"
