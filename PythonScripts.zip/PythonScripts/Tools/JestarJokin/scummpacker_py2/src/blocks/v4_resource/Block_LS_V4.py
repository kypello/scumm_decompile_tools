from blocks.common import BlockLocalScript
from blocks.v4_base import BlockDefaultV4

class BlockLSV4(BlockLocalScript, BlockDefaultV4):
    name = "LS"
