from blocks.v5_base import BlockSoundV5
from blocks.v6_base import BlockContainerV6

class BlockSOUV6(BlockSoundV5, BlockContainerV6):
    name = "SOU"
