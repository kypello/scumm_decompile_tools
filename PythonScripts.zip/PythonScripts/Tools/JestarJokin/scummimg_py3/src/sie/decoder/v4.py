from . import common

class DecoderV4(common.ImageDecoderVgaBase):
    pass