from . import common

class DecoderV6(common.ImageDecoderVgaBase):
    pass
