from . import common

class DecoderV5(common.ImageDecoderVgaBase):
    pass
