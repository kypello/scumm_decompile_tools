from . import common

class EncoderV4(common.ImageEncoderVgaBase):
    pass
