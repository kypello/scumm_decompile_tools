from . import common

class EncoderV6(common.ImageEncoderVgaBase):
    pass
