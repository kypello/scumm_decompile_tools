from . import common

class EncoderV5(common.ImageEncoderVgaBase):
    pass
